package com.omni.apilistner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.omni.apilistner.ApiListeners.ApiHit;
import com.omni.apilistner.ApiListeners.ApiResponse;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //For GET METHOD
        met();
        met2();

        //For POST METHOD
        met3();
    }


    private void met(){

       new ApiHit(this, "Put your URL here", "GET", new ApiResponse() {
           @Override
           public void onApiResponse(String response) {

               Log.e("res",response);

           }
       });
    }

    private void met2(){
        new ApiHit(this, "Put your URL here", "GET", new ApiResponse() {
            @Override
            public void onApiResponse(String response) {

                Log.e("res2",response);

            }
        });
    }

    private void met3(){
        JSONObject jsonObject= new JSONObject();
        try {

            jsonObject.put("KEY1","value1");
            jsonObject.put("KEY1","value1");
            jsonObject.put("KEY1","value1");
            jsonObject.put("KEY1","value1");
        }catch (JSONException e)
        {
            e.printStackTrace();
        }



        new ApiHit(this, "Put your URL here", "post", jsonObject,new ApiResponse() {
            @Override
            public void onApiResponse(String response) {

            }
        });
    }
}
