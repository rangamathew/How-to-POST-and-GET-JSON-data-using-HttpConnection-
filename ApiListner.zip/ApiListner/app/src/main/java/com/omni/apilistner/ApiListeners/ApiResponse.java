package com.omni.apilistner.ApiListeners;

/**
 * Created by Md Farhan Raja on 2/28/2017.
 */

public interface ApiResponse
{
    public void onApiResponse(String response);
}
