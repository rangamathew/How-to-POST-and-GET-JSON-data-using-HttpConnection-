package com.omni.apilistner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.omni.apilistner.ApiListeners.ApiHit;
import com.omni.apilistner.ApiListeners.ApiResponse;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        met();
        met2();
    }


    private void met(){

       new ApiHit(this, "http://www.igyaan.in/wp-json/wp/v2/posts?categories=66", "GET", new ApiResponse() {
           @Override
           public void onApiResponse(String response) {

               Log.e("res",response);

           }
       });
    }

    private void met2(){
        new ApiHit(this, "http://www.igyaan.in/wp-json/wp/v2/posts?categories=32758", "GET", new ApiResponse() {
            @Override
            public void onApiResponse(String response) {

                Log.e("res2",response);

            }
        });
    }

    private void met3(){
        new ApiHit(this, "", "get", new ApiResponse() {
            @Override
            public void onApiResponse(String response) {

            }
        });
    }
}
